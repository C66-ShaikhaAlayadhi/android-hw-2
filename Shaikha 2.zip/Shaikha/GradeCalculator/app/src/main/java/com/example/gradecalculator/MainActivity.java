package com.example.gradecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.awt.font.TextAttribute;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText x = findViewById(R.id.editTextTextPersonName9);
        final EditText y = findViewById(R.id.editTextTextPersonName12);
        final EditText z = findViewById(R.id.editTextTextPersonName13);
        final EditText f = findViewById(R.id.editTextTextPersonName14);
        Button add = findViewById(R.id.button2);
        final Button reset = findViewById(R.id.button3);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double a = Double.parseDouble(x.getText().toString());
                double b = Double.parseDouble(y.getText().toString());
                double c = Double.parseDouble(z.getText().toString());
                double d = Double.parseDouble(f.getText().toString());
                double e = a + b + c + d ;

                Toast.makeText(MainActivity.this,e+"", Toast.LENGTH_LONG).show();

                    }
                });

              reset.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
       x.setText("");
       y.setText("");
       z.setText("");
       f.setText("");

    }
     });
                    }
                };